#!/usr/bin/env python3
"""
Generates assets/hero.svg -- the animated terminal hero for the profile README.
Edit the CONFIG block, then run:  python3 gen_hero.py
"""
import json, html

# ---------------------------------------------------------------- CONFIG ----
NAME      = "Satvik Mishra"
GREETING  = "Hi"
ROLES     = [
    "AI Engineer · building in public",
    "LLM · RAG · Multi-Agent Systems",
    "Shipping Aletheon & Basalt",
    "Production Engineering undergrad",
]
META = [
    ("location",  "India",                      None),
    ("education", "Production Engineering",      None),
    ("focus",     "AI Engineer | LLM · RAG · Agents · Diagramming",
                  "PyTorch · LangChain · FastAPI · Docker · Neo4j"),
    ("portfolio", "github.com/auroraeye-dev",    None),
    ("email",     "aletheonai@gmail.com",        None),
]
SKILLS = [
    ["Python", "PyTorch", "LangChain", "RAG", "LLMs", "FastAPI", "Swift", "Docker"],
    ["Neo4j", "Next.js", "TypeScript", "Multi-Agent", "Computer Vision", "n8n"],
]
SOCIALS = ["GitHub", "LinkedIn", "X", "Portfolio"]
LEFT_TITLE  = "portrait.ascii"
RIGHT_TITLE = "~/whoami.sh"

# palette
BG        = "#05070d"
PANEL     = "#0b1220"
PANEL_TOP = "#111a2e"
EDGE      = "#1e2a44"
DIM       = "#64748b"
TEXT      = "#c7d2e4"
CYAN      = "#38e0c8"
BLUE      = "#4aa8ff"
VIOLET    = "#a78bfa"
# ----------------------------------------------------------------------------

W, H = 1000, 512
PAD = 18
LP_X, LP_W = PAD, 330
RP_X = LP_X + LP_W + 14
RP_W = W - RP_X - PAD
P_Y, P_H = PAD, H - 2 * PAD
BAR = 28

rows = json.load(open("assets/_ascii_rows.json"))
A_FS = min(11.0, (LP_W - 28) / (max(len(r) for r in rows) * 0.6))
A_LH = (P_H - BAR - 26) / len(rows)
A_X, A_Y = LP_X + 14, P_Y + BAR + 16 + A_LH * 0.6

e = html.escape
out = []
add = out.append
css = []


def panel(x, w, title, key):
    """Window chrome: body, title bar, traffic lights, centred title."""
    add(f'<rect x="{x}" y="{P_Y}" width="{w}" height="{P_H}" rx="12" '
        f'fill="url(#panelGrad)" stroke="{EDGE}"/>')
    add(f'<path d="M{x} {P_Y+12} a12 12 0 0 1 12 -12 h{w-24} a12 12 0 0 1 12 12 '
        f'v{BAR-12} h{-w} z" fill="{PANEL_TOP}"/>')
    add(f'<line x1="{x}" y1="{P_Y+BAR}" x2="{x+w}" y2="{P_Y+BAR}" stroke="{EDGE}"/>')
    for i, c in enumerate(("#ff5f57", "#febc2e", "#28c840")):
        add(f'<circle cx="{x+18+i*15}" cy="{P_Y+BAR/2}" r="4.5" fill="{c}" '
            f'class="dot" style="animation-delay:{i*0.35}s"/>')
    add(f'<text x="{x+w/2}" y="{P_Y+BAR/2+4}" class="chrome" text-anchor="middle">'
        f'{e(title)}</text>')


# ============================================================== background ==
add(f'<rect width="{W}" height="{H}" rx="20" fill="{BG}"/>')
add(f'<rect width="{W}" height="{H}" rx="20" fill="url(#dots)" opacity=".5"/>')
add(f'<circle cx="60" cy="40" r="220" fill="{CYAN}" opacity=".07" filter="url(#soft)"/>')
add(f'<circle cx="{W-80}" cy="{H}" r="240" fill="{VIOLET}" opacity=".08" filter="url(#soft)"/>')
add(f'<rect x="1" y="1" width="{W-2}" height="{H-2}" rx="20" fill="none" '
    f'stroke="url(#edgeGrad)" stroke-width="1.5"/>')

# ============================================================= left panel ===
panel(LP_X, LP_W, LEFT_TITLE, "l")
add(f'<clipPath id="asciiClip"><rect x="{LP_X+2}" y="{P_Y+BAR}" '
    f'width="{LP_W-4}" height="{P_H-BAR-2}"/></clipPath>')
add('<g clip-path="url(#asciiClip)">')
for i, r in enumerate(rows):
    y = A_Y + i * A_LH
    d = round(i * 0.045, 3)
    add(f'<text x="{A_X}" y="{y:.1f}" class="ascii" '
        f'style="animation-delay:{d}s,{d}s" xml:space="preserve">{e(r)}</text>')
# sweeping scan bar + horizontal readout line
add(f'<rect x="{LP_X+2}" y="{P_Y+BAR}" width="{LP_W-4}" height="64" '
    f'fill="url(#scanGrad)" class="scan"/>')
add(f'<rect x="{LP_X+2}" y="{P_Y+BAR}" width="{LP_W-4}" height="1.2" '
    f'fill="{CYAN}" opacity=".55" class="scanline"/>')
add('</g>')

# ============================================================ right panel ===
panel(RP_X, RP_W, RIGHT_TITLE, "r")
IX = RP_X + 24
IW = RP_W - 48

add(f'<text x="{IX}" y="{P_Y+BAR+30}" class="dimtxt rv" style="animation-delay:.15s">'
    f'{e(GREETING)}</text>')
add(f'<text x="{IX}" y="{P_Y+BAR+72}" class="name rv" style="animation-delay:.3s">'
    f'I&#8217;m {e(NAME)}</text>')

# ---- typing line
TY = P_Y + BAR + 106
TFS = 15.0
CH = TFS * 0.6
add(f'<text x="{IX}" y="{TY}" class="prompt">&#8250;</text>')
TX = IX + 18
CYCLE = len(ROLES) * 4.5
for i, role in enumerate(ROLES):
    s = i * 4.5
    n = len(role)
    wpx = n * CH
    p0 = s / CYCLE * 100
    p1 = (s + 1.35) / CYCLE * 100
    p2 = (s + 3.55) / CYCLE * 100
    p3 = (s + 4.25) / CYCLE * 100
    p4 = (s + 4.45) / CYCLE * 100
    css.append(f"""
@keyframes tw{i}{{
 0%,{p0:.3f}%{{width:0px;animation-timing-function:steps({n},end)}}
 {p1:.3f}%,{p2:.3f}%{{width:{wpx:.1f}px;animation-timing-function:steps({n},end)}}
 {p3:.3f}%,100%{{width:0px}}
}}
@keyframes tc{i}{{
 0%,{p0:.3f}%{{transform:translateX(0);animation-timing-function:steps({n},end)}}
 {p1:.3f}%,{p2:.3f}%{{transform:translateX({wpx:.1f}px);animation-timing-function:steps({n},end)}}
 {p3:.3f}%,100%{{transform:translateX(0)}}
}}
@keyframes tv{i}{{
 0%,{p0:.3f}%{{opacity:0}}
 {p0+0.01:.3f}%,{p4:.3f}%{{opacity:1}}
 {p4+0.01:.3f}%,100%{{opacity:0}}
}}
#clip{i} rect{{animation:tw{i} {CYCLE}s infinite}}
#cur{i}{{animation:tc{i} {CYCLE}s infinite}}
#ph{i}{{animation:tv{i} {CYCLE}s infinite}}""")
    add(f'<clipPath id="clip{i}"><rect x="{TX}" y="{TY-TFS}" width="0" '
        f'height="{TFS*1.5:.0f}"/></clipPath>')
    add(f'<g id="ph{i}" opacity="0">'
        f'<text x="{TX}" y="{TY}" class="role" clip-path="url(#clip{i})" '
        f'xml:space="preserve">{e(role)}</text>'
        f'<rect id="cur{i}" x="{TX}" y="{TY-12}" width="8.5" height="16" rx="1.5" '
        f'fill="{CYAN}" class="caret"/></g>')

# ---- meta rows
my = P_Y + BAR + 150
LABX, VALX = IX, IX + 116
for mi, (label, val, sub) in enumerate(META):
    d = 0.5 + mi * 0.12
    add(f'<g class="rv" style="animation-delay:{d:.2f}s">')
    add(f'<text x="{LABX}" y="{my}" class="key">{e(label)}</text>')
    add(f'<text x="{VALX}" y="{my}" class="val">{e(val)}</text>')
    if sub:
        my += 19
        add(f'<text x="{VALX}" y="{my}" class="sub">{e(sub)}</text>')
    add('</g>')
    my += 27

# ---- skills
sy = my + 6
add(f'<text x="{IX}" y="{sy}" class="section rv" style="animation-delay:1.15s">SKILLS</text>')
cy = sy + 12
CFS, CCH, CHH = 12.0, 7.2, 27
k = 0
for row in SKILLS:
    cx = IX
    for s in row:
        cw = len(s) * CCH + 22
        d = 1.25 + k * 0.06
        add(f'<g class="chip" style="animation-delay:{d:.2f}s">'
            f'<rect x="{cx:.1f}" y="{cy}" width="{cw:.1f}" height="{CHH}" rx="13.5" '
            f'fill="#0f1a2e" stroke="#25374f"/>'
            f'<text x="{cx+cw/2:.1f}" y="{cy+18}" class="chiptxt" text-anchor="middle">'
            f'{e(s)}</text></g>')
        cx += cw + 8
        k += 1
    cy += CHH + 8

# ---- socials
gy = cy + 16
gx = IX + 18
for i, s in enumerate(SOCIALS):
    d = 1.6 + i * 0.09
    add(f'<g class="rv" style="animation-delay:{d:.2f}s">'
        f'<circle cx="{gx}" cy="{gy}" r="15" fill="#0f1a2e" stroke="#25374f" class="orb" '
        f'style="animation-delay:{i*0.4}s"/>'
        f'<text x="{gx}" y="{gy+4}" class="ico" text-anchor="middle">'
        f'{e(s[0])}</text>'
        f'<text x="{gx}" y="{gy+30}" class="sociallbl" text-anchor="middle">{e(s)}</text></g>')
    gx += 74

# ================================================================== styles ==
STYLE = f"""
text{{font-family:ui-monospace,'SFMono-Regular',Menlo,Consolas,'Liberation Mono',monospace}}
.chrome{{font-size:11.5px;fill:#63728c;letter-spacing:.4px}}
.dimtxt{{font-size:13px;fill:{DIM}}}
.name{{font-size:31px;font-weight:700;fill:url(#nameGrad);letter-spacing:-.4px;
      filter:url(#nameGlow)}}
.prompt{{font-size:16px;fill:{CYAN}}}
.role{{font-size:{TFS}px;fill:#9fb3cd}}
.key{{font-size:12.5px;fill:#55617a;letter-spacing:.5px}}
.val{{font-size:13px;fill:{TEXT}}}
.sub{{font-size:11.5px;fill:#6b7a95}}
.section{{font-size:11px;fill:#55617a;letter-spacing:2.2px}}
.chiptxt{{font-size:{CFS}px;fill:#b9cbe4}}
.ico{{font-size:12px;font-weight:700;fill:{CYAN}}}
.sociallbl{{font-size:10px;fill:#55617a}}
.ascii{{font-size:{A_FS}px;fill:url(#asciiGrad);opacity:0;
       animation:rev .5s ease-out both,flick 7s ease-in-out infinite}}

@keyframes rev{{from{{opacity:0;transform:translateX(-6px)}}to{{opacity:.95;transform:none}}}}
@keyframes flick{{0%,100%{{opacity:.95}}47%{{opacity:.68}}53%{{opacity:1}}}}
.rv{{opacity:0;animation:rv .7s cubic-bezier(.2,.7,.3,1) both}}
@keyframes rv{{from{{opacity:0;transform:translateY(8px)}}to{{opacity:1;transform:none}}}}
.chip{{opacity:0;animation:chip .5s cubic-bezier(.2,.8,.3,1) both}}
@keyframes chip{{from{{opacity:0;transform:translateY(6px) scale(.94)}}
                to{{opacity:1;transform:none}}}}
.caret{{animation:blink 1.05s steps(1,end) infinite}}
@keyframes blink{{0%,49%{{opacity:1}}50%,100%{{opacity:.05}}}}
.dot{{animation:pulse 3.2s ease-in-out infinite}}
@keyframes pulse{{0%,100%{{opacity:1}}50%{{opacity:.45}}}}
.orb{{animation:orb 4s ease-in-out infinite}}
@keyframes orb{{0%,100%{{stroke:#25374f}}50%{{stroke:{CYAN}}}}}
.scan{{animation:scan 5.5s cubic-bezier(.45,0,.55,1) infinite;opacity:.5}}
@keyframes scan{{0%{{transform:translateY(-70px)}}100%{{transform:translateY({P_H-BAR}px)}}}}
.scanline{{animation:scan2 5.5s cubic-bezier(.45,0,.55,1) infinite}}
@keyframes scan2{{0%{{transform:translateY(0)}}100%{{transform:translateY({P_H-BAR}px)}}}}
#g1{{animation:hue 9s linear infinite}}
@keyframes hue{{0%{{stop-color:{CYAN}}}33%{{stop-color:{BLUE}}}
               66%{{stop-color:{VIOLET}}}100%{{stop-color:{CYAN}}}}}
#g2{{animation:hue2 9s linear infinite}}
@keyframes hue2{{0%{{stop-color:{VIOLET}}}33%{{stop-color:{CYAN}}}
                66%{{stop-color:{BLUE}}}100%{{stop-color:{VIOLET}}}}}
#e1{{animation:hue 11s linear infinite}}
#e2{{animation:hue2 11s linear infinite}}
{''.join(css)}
"""

DEFS = f"""
<linearGradient id="nameGrad" x1="0" y1="0" x2="1" y2="0">
  <stop id="g1" offset="0%" stop-color="{CYAN}"/>
  <stop offset="50%" stop-color="{BLUE}"/>
  <stop id="g2" offset="100%" stop-color="{VIOLET}"/>
</linearGradient>
<linearGradient id="edgeGrad" x1="0" y1="0" x2="1" y2="1">
  <stop id="e1" offset="0%" stop-color="{CYAN}" stop-opacity=".55"/>
  <stop offset="50%" stop-color="#1b2740" stop-opacity=".6"/>
  <stop id="e2" offset="100%" stop-color="{VIOLET}" stop-opacity=".55"/>
</linearGradient>
<linearGradient id="panelGrad" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0%" stop-color="#0d1526"/><stop offset="100%" stop-color="#080d18"/>
</linearGradient>
<linearGradient id="asciiGrad" x1="0" y1="0" x2="0.4" y2="1">
  <stop offset="0%" stop-color="#7fe7ff"/><stop offset="55%" stop-color="{CYAN}"/>
  <stop offset="100%" stop-color="#3f7fd1"/>
</linearGradient>
<linearGradient id="scanGrad" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0%" stop-color="{CYAN}" stop-opacity="0"/>
  <stop offset="100%" stop-color="{CYAN}" stop-opacity=".18"/>
</linearGradient>
<filter id="soft" x="-60%" y="-60%" width="220%" height="220%">
  <feGaussianBlur stdDeviation="60"/></filter>
<filter id="nameGlow" x="-25%" y="-60%" width="150%" height="220%">
  <feGaussianBlur stdDeviation="7" result="b"/>
  <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
<pattern id="dots" width="22" height="22" patternUnits="userSpaceOnUse">
  <circle cx="1" cy="1" r="1" fill="#16203a"/></pattern>
"""

svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
       f'viewBox="0 0 {W} {H}" fill="none" role="img" '
       f'aria-label="{e(NAME)} — {e(ROLES[0])}">\n'
       f'<defs>{DEFS}</defs>\n<style>{STYLE}</style>\n'
       + "\n".join(out) + "\n</svg>\n")

open("assets/hero.svg", "w").write(svg)
print(f"assets/hero.svg written — {len(svg)/1024:.1f} KB, {W}x{H}")
