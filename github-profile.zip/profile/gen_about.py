#!/usr/bin/env python3
"""Generates assets/about.svg -- the animated ~/about.md card."""
import html

# ---------------------------------------------------------------- CONFIG ----
TITLE   = "~/about.md"
HEADING = "About Me"
PARAS = [
    "I build end-to-end AI systems — from raw data pipelines to deployed,",
    "containerised LLM applications. RAG, multi-agent workflows, computer",
    "vision, and the unglamorous plumbing that makes them hold up in prod.",
]
LOGLINE = "$ cat shipped.log"
ITEMS = [
    ("Basalt",             "AI architecture diagramming for OT/ICS + cloud,",
                           "backed by a deterministic validator."),
    ("Aletheon",           "Drug-intelligence report generation — a RAG pipeline",
                           "tuned for source-grounding fidelity."),
    ("Samcast",            "Gesture-based casting that moves screen content",
                           "between macOS and iPadOS. Swift."),
    ("BDH Foundation LLM", "Lightweight language model that reads books and",
                           "judges character-level consistency."),
    ("IMC Prosperity 4",   "Fully self-contained, reproducible research for the",
                           "algorithmic trading competition."),
    ("Always shipping",    "Daily DSA practice, side experiments, and whatever",
                           "the current obsession happens to be."),
]
BG, PANEL_TOP, EDGE = "#05070d", "#111a2e", "#1e2a44"
CYAN, BLUE, VIOLET = "#38e0c8", "#4aa8ff", "#a78bfa"
# ----------------------------------------------------------------------------

W = 1000
PAD, BAR = 18, 28
e = html.escape
o = []
add = o.append

IX = PAD + 26
IW = W - 2 * IX

hy = PAD + BAR + 40                      # heading baseline
py = hy + 30                             # first paragraph baseline
ly = py + len(PARAS) * 22 + 20           # shipped.log baseline
by = ly + 32                             # first bullet block top
ROWH, COLS = 58, 2
COLW = (IW - 26) / COLS
nrows = (len(ITEMS) + COLS - 1) // COLS
H = int(by + nrows * ROWH + 26)
P_H = H - 2 * PAD

# ---- frame
add(f'<rect width="{W}" height="{H}" rx="20" fill="{BG}"/>')
add(f'<rect width="{W}" height="{H}" rx="20" fill="url(#dots)" opacity=".5"/>')
add(f'<circle cx="{W-60}" cy="30" r="200" fill="{BLUE}" opacity=".07" filter="url(#soft)"/>')
add(f'<circle cx="40" cy="{H}" r="200" fill="{VIOLET}" opacity=".07" filter="url(#soft)"/>')
add(f'<rect x="1" y="1" width="{W-2}" height="{H-2}" rx="20" fill="none" '
    f'stroke="url(#edgeGrad)" stroke-width="1.5"/>')
add(f'<rect x="{PAD}" y="{PAD}" width="{W-2*PAD}" height="{P_H}" rx="12" '
    f'fill="url(#panelGrad)" stroke="{EDGE}"/>')
add(f'<path d="M{PAD} {PAD+12} a12 12 0 0 1 12 -12 h{W-2*PAD-24} a12 12 0 0 1 12 12 '
    f'v{BAR-12} h{-(W-2*PAD)} z" fill="{PANEL_TOP}"/>')
add(f'<line x1="{PAD}" y1="{PAD+BAR}" x2="{W-PAD}" y2="{PAD+BAR}" stroke="{EDGE}"/>')
for i, c in enumerate(("#ff5f57", "#febc2e", "#28c840")):
    add(f'<circle cx="{PAD+18+i*15}" cy="{PAD+BAR/2}" r="4.5" fill="{c}" '
        f'class="dot" style="animation-delay:{i*0.35}s"/>')
add(f'<text x="{W/2}" y="{PAD+BAR/2+4}" class="chrome" text-anchor="middle">{e(TITLE)}</text>')

# ---- heading with sweeping highlight
hw = len(HEADING) * 13.2 + 14
add(f'<rect x="{IX-6}" y="{hy-21}" width="0" height="28" rx="5" fill="{CYAN}" '
    f'opacity=".16" class="hl"><animate attributeName="width" values="0;{hw:.0f};{hw:.0f}" '
    f'dur="2.4s" keyTimes="0;0.35;1" fill="freeze" begin="0.2s"/></rect>')
add(f'<text x="{IX}" y="{hy}" class="h1 rv" style="animation-delay:.25s">{e(HEADING)}</text>')

for i, p in enumerate(PARAS):
    add(f'<text x="{IX}" y="{py+i*22}" class="para rv" '
        f'style="animation-delay:{0.5+i*0.12:.2f}s">{e(p)}</text>')

add(f'<g class="rv" style="animation-delay:.95s">'
    f'<text x="{IX}" y="{ly}" class="logline">{e(LOGLINE)}</text>'
    f'<rect x="{IX + len(LOGLINE)*(12.5*0.6+1.4) + 4:.0f}" y="{ly-11}" width="8" height="15" rx="1.5" '
    f'fill="{CYAN}" class="caret"/></g>')

# ---- bullet grid
for i, (t, d1, d2) in enumerate(ITEMS):
    col, row = i % COLS, i // COLS
    x = IX + col * (COLW + 26)
    y = by + row * ROWH
    dl = 1.15 + i * 0.1
    add(f'<g class="rv" style="animation-delay:{dl:.2f}s">')
    add(f'<circle cx="{x+4:.0f}" cy="{y+7}" r="3.6" fill="{CYAN}" class="bdot" '
        f'style="animation-delay:{i*0.5}s"/>')
    add(f'<text x="{x+20:.0f}" y="{y+12}" class="btitle">{e(t)}</text>')
    add(f'<text x="{x+20:.0f}" y="{y+31}" class="bdesc">{e(d1)}</text>')
    add(f'<text x="{x+20:.0f}" y="{y+47}" class="bdesc">{e(d2)}</text>')
    add('</g>')

STYLE = f"""
text{{font-family:ui-monospace,'SFMono-Regular',Menlo,Consolas,'Liberation Mono',monospace}}
.chrome{{font-size:11.5px;fill:#63728c;letter-spacing:.4px}}
.h1{{font-size:22px;font-weight:700;fill:url(#nameGrad)}}
.para{{font-size:13.2px;fill:#9fb3cd}}
.logline{{font-size:12.5px;fill:#55617a;letter-spacing:1.4px}}
.btitle{{font-size:13.5px;font-weight:700;fill:#dbe6f5}}
.bdesc{{font-size:11.8px;fill:#77879f}}
.rv{{opacity:0;animation:rv .7s cubic-bezier(.2,.7,.3,1) both}}
@keyframes rv{{from{{opacity:0;transform:translateY(9px)}}to{{opacity:1;transform:none}}}}
.caret{{animation:blink 1.05s steps(1,end) infinite}}
@keyframes blink{{0%,49%{{opacity:1}}50%,100%{{opacity:.05}}}}
.dot{{animation:pulse 3.2s ease-in-out infinite}}
@keyframes pulse{{0%,100%{{opacity:1}}50%{{opacity:.45}}}}
.bdot{{animation:bd 3.6s ease-in-out infinite}}
@keyframes bd{{0%,100%{{opacity:.45;r:3.2}}50%{{opacity:1;r:4.2}}}}
#g1{{animation:hue 9s linear infinite}}
@keyframes hue{{0%{{stop-color:{CYAN}}}33%{{stop-color:{BLUE}}}
               66%{{stop-color:{VIOLET}}}100%{{stop-color:{CYAN}}}}}
#g2{{animation:hue2 9s linear infinite}}
@keyframes hue2{{0%{{stop-color:{VIOLET}}}33%{{stop-color:{CYAN}}}
                66%{{stop-color:{BLUE}}}100%{{stop-color:{VIOLET}}}}}
#e1{{animation:hue 11s linear infinite}}
#e2{{animation:hue2 11s linear infinite}}
"""

DEFS = f"""
<linearGradient id="nameGrad" x1="0" y1="0" x2="1" y2="0">
  <stop id="g1" offset="0%" stop-color="{CYAN}"/>
  <stop offset="50%" stop-color="{BLUE}"/>
  <stop id="g2" offset="100%" stop-color="{VIOLET}"/>
</linearGradient>
<linearGradient id="edgeGrad" x1="0" y1="0" x2="1" y2="1">
  <stop id="e1" offset="0%" stop-color="{CYAN}" stop-opacity=".55"/>
  <stop offset="50%" stop-color="#1b2740" stop-opacity=".6"/>
  <stop id="e2" offset="100%" stop-color="{VIOLET}" stop-opacity=".55"/>
</linearGradient>
<linearGradient id="panelGrad" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0%" stop-color="#0d1526"/><stop offset="100%" stop-color="#080d18"/>
</linearGradient>
<filter id="soft" x="-60%" y="-60%" width="220%" height="220%">
  <feGaussianBlur stdDeviation="60"/></filter>
<pattern id="dots" width="22" height="22" patternUnits="userSpaceOnUse">
  <circle cx="1" cy="1" r="1" fill="#16203a"/></pattern>
"""

svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
       f'viewBox="0 0 {W} {H}" fill="none" role="img" aria-label="About me">\n'
       f'<defs>{DEFS}</defs>\n<style>{STYLE}</style>\n' + "\n".join(o) + "\n</svg>\n")
open("assets/about.svg", "w").write(svg)
print(f"assets/about.svg written — {W}x{H}")
