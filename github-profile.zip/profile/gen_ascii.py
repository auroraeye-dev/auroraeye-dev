"""Generate a dithered ASCII 'bust portrait' and emit SVG <text> rows."""
import math, random, json

random.seed(7)
W, H = 46, 30  # cols, rows  (terminal char grid)

def field(x, y):
    """Return 0..1 luminance for a stylised bust silhouette."""
    # normalise to -1..1 with y down
    nx = (x - W / 2) / (W / 2)
    ny = (y - H / 2) / (H / 2)

    v = 0.0
    # head: ellipse centred slightly above middle
    hx, hy = nx / 0.42, (ny + 0.42) / 0.46
    hd = math.hypot(hx, hy)
    if hd < 1.0:
        v = max(v, 1.0 - hd * 0.55)

    # shoulders / torso: wide rounded shape at the bottom
    sx, sy = nx / 0.95, (ny - 0.72) / 0.62
    sd = math.hypot(sx, sy)
    if sd < 1.0 and ny > -0.02:
        v = max(v, 1.0 - sd * 0.5)

    # neck
    if abs(nx) < 0.13 and -0.1 < ny < 0.32:
        v = max(v, 0.72)

    # directional light from upper-left
    v *= 0.62 + 0.55 * (1.0 - (nx + 1) / 2) * (1.0 - (ny + 1) / 2) * 1.6

    # soft vignette + subtle noise so it dithers like the reference
    v *= 1.0 - 0.18 * math.hypot(nx, ny)
    v += random.uniform(-0.09, 0.09)
    return max(0.0, min(1.0, v))

RAMP = " .:-=+*#%@$"
rows = []
for y in range(H):
    line = ""
    for x in range(W):
        v = field(x, y)
        if v <= 0.06:
            # faint background static, like the reference's dark field
            line += random.choice("  ..:") if random.random() < 0.16 else " "
        else:
            line += RAMP[min(len(RAMP) - 1, int(v * (len(RAMP) - 1) + 0.5))]
    rows.append(line.rstrip())

with open("assets/_ascii_rows.json", "w") as f:
    json.dump(rows, f)

print("\n".join(rows))
